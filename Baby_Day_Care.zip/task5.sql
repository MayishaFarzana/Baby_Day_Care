set serveroutput on;

declare 

id number;
f integer;
begin
    id := &Enter_last_3_digits_of_you_id;
    begin
        if (mod(id, 2) = 0) then
            f := 1;
        else 
        	f := 0;
        end if;
    end;
    if (f = 1) then
        dbms_output.put_line('Even');
    else 
        dbms_output.put_line('Odd');
    end if;
end;
/