set serveroutput on;
drop table students;
create table students
(
	name varchar2(25),
	cgpa number
);


insert into students(name,cgpa) values('Walter White',3.71);
insert into students(name,cgpa) values('Jesse Pinkman',3.20);
select *from students;
commit;
insert into students values('Gus Fring',3.50);
DELETE FROM students WHERE cgpa < 3.65;

UPDATE students SET cgpa = cgpa + 0.01 WHERE name LIKE '%Fring%';
UPDATE students SET name = 'Heisenberg' WHERE name= 'Walter White';
UPDATE students SET cgpa = cgpa + 0.01;
