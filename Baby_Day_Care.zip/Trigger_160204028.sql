set serveroutput on;
create or replace trigger FUN1
after insert on
students
for each row
begin
	dbms_output.put_line('FUN1');
end ;
/	
create or replace trigger FUN2
before  insert on
on students
for each row
begin
	dbms_output.put_line('FUN2');
end;

create or replace trigger FUN3
after insert or delete 
on students
for each row
begin
	dbms_output.put_line('FUN3');
end;
/
create or replace trigger FUN4
after update
of cgpa
on students
for each row
begin
	dbms_output.put_line('FUN4');

end;
/
create or replace trigger FUN5
after update 
on students
for each row
begin
	dbms_output.put_line('FUN5');

end;
/











