set serveroutput on;
create or replace trigger INVALID_NAME
after insert on students

declare
	
	v_age student.name%TYPE;
	
	
	error_name exception;
begin


exception

	when error_name then
		dbms_output.put_line('name invalid');
end;
/